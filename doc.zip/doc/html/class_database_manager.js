var class_database_manager =
[
    [ "DatabaseManager", "class_database_manager.html#ad2d0cf2163f6dd1d932de293e6f9ea1b", null ],
    [ "~DatabaseManager", "class_database_manager.html#ae9b3a5da1e04fbb00faf8a034da1d063", null ],
    [ "authenticateUser", "class_database_manager.html#ae6ecb7e58f5230cf50a1cebbf15f4692", null ],
    [ "checkSolution", "class_database_manager.html#a3423b01aeae592e0006c1c01091a80c8", null ],
    [ "getUserStats", "class_database_manager.html#abd068f2dccd6cc610979e54b1ff1869d", null ],
    [ "initialize", "class_database_manager.html#ab4c1d7b625f6511bf5048882778c29cf", null ],
    [ "registerUser", "class_database_manager.html#a9d169bb8ce652e0e5cc1b65646f181f7", null ],
    [ "solveEquation", "class_database_manager.html#aa9f69da76c115f6f5856ff850519bfe5", null ],
    [ "updateUserStats", "class_database_manager.html#aa178460ff906cd851acf5fd15c9e34ae", null ],
    [ "userExists", "class_database_manager.html#a1eb2c65bc79c1b45cdf89d733c05f7b7", null ]
];