var class_server_view =
[
    [ "ServerView", "class_server_view.html#afd8921e05e8559fe6e4b2f3a5f3d587b", null ],
    [ "displayError", "class_server_view.html#afb6d9bb328e85df8e472d7af4e8eb8c5", null ],
    [ "displayMessage", "class_server_view.html#a9715c9b5ec1b419e6a783e0b095d5589", null ]
];