var searchData=
[
  ['solvedtasks_0',['solvedTasks',['../struct_user_stats.html#a394728db67ea3dbe85bbfbbea4ea679e',1,'UserStats']]]
];
