var searchData=
[
  ['generategraphpoints_0',['generateGraphPoints',['../class_function_solver.html#aa16bdba59b0bfa1f2da2279bd7c292b2',1,'FunctionSolver']]],
  ['geta_1',['getA',['../class_function_solver.html#a1a23faf0162594c86cdc34ce08784bd3',1,'FunctionSolver']]],
  ['getb_2',['getB',['../class_function_solver.html#a25570ba8ff1e6f984e2373a81a8c3772',1,'FunctionSolver']]],
  ['getpiece_3',['getPiece',['../class_function_solver.html#a7db78da3253b85a90f5286ddcf28bbd3',1,'FunctionSolver']]],
  ['getuserstats_4',['getUserStats',['../class_database_manager.html#abd068f2dccd6cc610979e54b1ff1869d',1,'DatabaseManager']]]
];
