var searchData=
[
  ['userstats_0',['UserStats',['../struct_user_stats.html',1,'']]]
];
