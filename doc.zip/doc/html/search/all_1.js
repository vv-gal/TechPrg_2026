var searchData=
[
  ['checksolution_0',['checkSolution',['../class_database_manager.html#a3423b01aeae592e0006c1c01091a80c8',1,'DatabaseManager']]],
  ['currentscore_1',['currentScore',['../struct_user_stats.html#a8b69e194c892014bfe8b6567c0403f85',1,'UserStats']]]
];
