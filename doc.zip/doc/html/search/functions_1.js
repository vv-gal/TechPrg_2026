var searchData=
[
  ['checksolution_0',['checkSolution',['../class_database_manager.html#a3423b01aeae592e0006c1c01091a80c8',1,'DatabaseManager']]]
];
