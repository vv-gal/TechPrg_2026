var searchData=
[
  ['piece_0',['piece',['../struct_solution_point.html#acb9fac0f251a6fa53cd4e53d7a78d3aa',1,'SolutionPoint']]]
];
