var searchData=
[
  ['incomingconnection_0',['incomingConnection',['../class_server_controller.html#a18b48a0eeab01b89fc3ae6460e8bde5e',1,'ServerController']]],
  ['initialize_1',['initialize',['../class_database_manager.html#ab4c1d7b625f6511bf5048882778c29cf',1,'DatabaseManager']]]
];
