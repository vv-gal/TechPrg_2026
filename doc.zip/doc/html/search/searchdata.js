var indexSectionsWithContent =
{
  0: "acdefgimpqrstuxy~",
  1: "dfqsu",
  2: "dfms",
  3: "acdefgimrsu~",
  4: "cdpstxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

