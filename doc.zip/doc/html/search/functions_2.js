var searchData=
[
  ['databasemanager_0',['DatabaseManager',['../class_database_manager.html#ad2d0cf2163f6dd1d932de293e6f9ea1b',1,'DatabaseManager']]],
  ['displayerror_1',['displayError',['../class_server_view.html#afb6d9bb328e85df8e472d7af4e8eb8c5',1,'ServerView']]],
  ['displaymessage_2',['displayMessage',['../class_server_view.html#a9715c9b5ec1b419e6a783e0b095d5589',1,'ServerView']]]
];
