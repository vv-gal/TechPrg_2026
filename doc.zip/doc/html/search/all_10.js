var searchData=
[
  ['_7edatabasemanager_0',['~DatabaseManager',['../class_database_manager.html#ae9b3a5da1e04fbb00faf8a034da1d063',1,'DatabaseManager']]],
  ['_7eservercontroller_1',['~ServerController',['../class_server_controller.html#a5283de069274288cb866a5fe12501e73',1,'ServerController']]]
];
