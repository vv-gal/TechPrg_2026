var searchData=
[
  ['authenticateuser_0',['authenticateUser',['../class_database_manager.html#ae6ecb7e58f5230cf50a1cebbf15f4692',1,'DatabaseManager']]]
];
