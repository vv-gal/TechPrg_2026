var searchData=
[
  ['databasemanager_0',['DatabaseManager',['../class_database_manager.html',1,'DatabaseManager'],['../class_database_manager.html#ad2d0cf2163f6dd1d932de293e6f9ea1b',1,'DatabaseManager::DatabaseManager()']]],
  ['databasemanager_2ecpp_1',['databasemanager.cpp',['../databasemanager_8cpp.html',1,'']]],
  ['databasemanager_2eh_2',['databasemanager.h',['../databasemanager_8h.html',1,'']]],
  ['description_3',['description',['../struct_solution_point.html#a9118321bc7bdc0e13d83ed03398c0af9',1,'SolutionPoint']]],
  ['displayerror_4',['displayError',['../class_server_view.html#afb6d9bb328e85df8e472d7af4e8eb8c5',1,'ServerView']]],
  ['displaymessage_5',['displayMessage',['../class_server_view.html#a9715c9b5ec1b419e6a783e0b095d5589',1,'ServerView']]]
];
