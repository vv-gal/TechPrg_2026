var searchData=
[
  ['updateuserstats_0',['updateUserStats',['../class_database_manager.html#aa178460ff906cd851acf5fd15c9e34ae',1,'DatabaseManager']]],
  ['userexists_1',['userExists',['../class_database_manager.html#a1eb2c65bc79c1b45cdf89d733c05f7b7',1,'DatabaseManager']]]
];
