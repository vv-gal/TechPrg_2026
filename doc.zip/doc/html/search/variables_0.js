var searchData=
[
  ['currentscore_0',['currentScore',['../struct_user_stats.html#a8b69e194c892014bfe8b6567c0403f85',1,'UserStats']]]
];
