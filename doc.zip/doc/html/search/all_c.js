var searchData=
[
  ['totalattempts_0',['totalAttempts',['../struct_user_stats.html#a9576ccc66e6054f92d8b69d2a0b75982',1,'UserStats']]]
];
