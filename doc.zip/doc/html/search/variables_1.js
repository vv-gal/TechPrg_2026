var searchData=
[
  ['description_0',['description',['../struct_solution_point.html#a9118321bc7bdc0e13d83ed03398c0af9',1,'SolutionPoint']]]
];
