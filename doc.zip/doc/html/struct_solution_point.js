var struct_solution_point =
[
    [ "description", "struct_solution_point.html#a9118321bc7bdc0e13d83ed03398c0af9", null ],
    [ "piece", "struct_solution_point.html#acb9fac0f251a6fa53cd4e53d7a78d3aa", null ],
    [ "x", "struct_solution_point.html#aa720b38bfe7cb2fbbbbe452be2293aaa", null ],
    [ "y", "struct_solution_point.html#a68caa78a207e5b71d4ef39b3daf77057", null ]
];