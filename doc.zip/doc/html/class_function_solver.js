var class_function_solver =
[
    [ "FunctionSolver", "class_function_solver.html#a888ec7bd4efd3a66ee81d4e29fe2f64f", null ],
    [ "evaluate", "class_function_solver.html#a6d95d5658e5a3de9b0d94237c3317b28", null ],
    [ "findAllRoots", "class_function_solver.html#a3b54c46203a660388002a504f807d4f9", null ],
    [ "generateGraphPoints", "class_function_solver.html#aa16bdba59b0bfa1f2da2279bd7c292b2", null ],
    [ "getA", "class_function_solver.html#a1a23faf0162594c86cdc34ce08784bd3", null ],
    [ "getB", "class_function_solver.html#a25570ba8ff1e6f984e2373a81a8c3772", null ],
    [ "getPiece", "class_function_solver.html#a7db78da3253b85a90f5286ddcf28bbd3", null ],
    [ "setParameters", "class_function_solver.html#acf14f9662aba7d0314c490ede52e67d4", null ],
    [ "solveBisection", "class_function_solver.html#a0c65098f105fc0f09bfb2062bb43fd56", null ]
];