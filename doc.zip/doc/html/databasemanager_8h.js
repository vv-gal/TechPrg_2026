var databasemanager_8h =
[
    [ "UserStats", "struct_user_stats.html", "struct_user_stats" ],
    [ "DatabaseManager", "class_database_manager.html", "class_database_manager" ]
];