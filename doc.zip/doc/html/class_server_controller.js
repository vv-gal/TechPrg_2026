var class_server_controller =
[
    [ "ServerController", "class_server_controller.html#a370f6da0c01a6b013020aa11c5161751", null ],
    [ "~ServerController", "class_server_controller.html#a5283de069274288cb866a5fe12501e73", null ],
    [ "incomingConnection", "class_server_controller.html#a18b48a0eeab01b89fc3ae6460e8bde5e", null ],
    [ "startServer", "class_server_controller.html#ac9a2649c269c5bf3a371f8df17164870", null ],
    [ "stopServer", "class_server_controller.html#abef244cc25ddcffeb9e444c33abb1197", null ]
];