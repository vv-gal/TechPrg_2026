var struct_user_stats =
[
    [ "currentScore", "struct_user_stats.html#a8b69e194c892014bfe8b6567c0403f85", null ],
    [ "solvedTasks", "struct_user_stats.html#a394728db67ea3dbe85bbfbbea4ea679e", null ],
    [ "totalAttempts", "struct_user_stats.html#a9576ccc66e6054f92d8b69d2a0b75982", null ]
];