var annotated_dup =
[
    [ "DatabaseManager", "class_database_manager.html", "class_database_manager" ],
    [ "FunctionSolver", "class_function_solver.html", "class_function_solver" ],
    [ "QObject", "class_q_object.html", null ],
    [ "QTcpServer", "class_q_tcp_server.html", null ],
    [ "ServerController", "class_server_controller.html", "class_server_controller" ],
    [ "ServerView", "class_server_view.html", "class_server_view" ],
    [ "SolutionPoint", "struct_solution_point.html", "struct_solution_point" ],
    [ "UserStats", "struct_user_stats.html", "struct_user_stats" ]
];