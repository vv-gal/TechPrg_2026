var dir_3f14f6767c31cb4a1d22c13c18cc6fc3 =
[
    [ "databasemanager.cpp", "databasemanager_8cpp.html", null ],
    [ "databasemanager.h", "databasemanager_8h.html", "databasemanager_8h" ],
    [ "functionSolver.cpp", "function_solver_8cpp.html", null ],
    [ "functionSolver.h", "function_solver_8h_source.html", null ]
];