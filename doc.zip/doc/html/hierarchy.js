var hierarchy =
[
    [ "DatabaseManager", "class_database_manager.html", null ],
    [ "FunctionSolver", "class_function_solver.html", null ],
    [ "QObject", "class_q_object.html", [
      [ "ServerView", "class_server_view.html", null ]
    ] ],
    [ "QTcpServer", "class_q_tcp_server.html", [
      [ "ServerController", "class_server_controller.html", null ]
    ] ],
    [ "SolutionPoint", "struct_solution_point.html", null ],
    [ "UserStats", "struct_user_stats.html", null ]
];